/**
 * 
 */
package itech2306Package1;

/**
 * @author Kkeogh
 *
 */
public class Animal {
	String name;
	String address;
	String birthofdate;
	
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	/**
	 * @param name the name to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	public String getBirthofdate() {
		return birthofdate;
	}
	/**
	 * @param name the name to set
	 */
	public void setBirthofday(String birthofdate) {
		this.birthofdate = birthofdate;
	}
	

}
