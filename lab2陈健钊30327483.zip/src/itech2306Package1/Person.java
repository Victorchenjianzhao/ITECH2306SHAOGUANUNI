/**
 * 
 */
package itech2306Package1;

import java.util.Random;

/**
 * @author kkeogh
 *
 */
public class Person {
	String name;
	String address;
	String postcode;
	String addAPet;
	private Object pet;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPostcode() {
		return postcode;
	}
	/**
	 * @param address the address to set
	 */
	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}
	public String getAddAPet() {
		return getAddAPet();
	}
	/**
	 * @param address the address to set
	 */
	public void setAddAPet(String addAPet) {
		this.addAPet = addAPet;
	}
	
	void addAPet(Animal pet){
		Object _pet;
		this.pet= pet;
	}
	Person ()
	{
		this.setAddress ( address);
		this.setName( name);
		this.setPostcode ( postcode);
	}
		

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person p = new Person();
		Animal myPet=new Animal();//����һ���µ�Animal����
		p.addAPet (myPet);
		int max=10;
		 int min=1;
		 
		 Random random = new Random();

		 int s = random.nextInt(max)%(max-min+1) + min;
		 if(s%2==0) {
		System.out.println(s+" even");
	   }
		 else {
		System.out.println(s+" impar");
	}
}
}


