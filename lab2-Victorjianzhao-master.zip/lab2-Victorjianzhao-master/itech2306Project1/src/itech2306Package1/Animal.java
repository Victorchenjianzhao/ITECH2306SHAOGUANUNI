/**
 * 
 */
package itech2306Package1;

/**
 * @author Kkeogh
 *
 */
public class Animal {

}
